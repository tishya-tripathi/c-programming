/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("Enter a string\n");
    
    char* str = (char* )malloc(sizeof(char));
    
    scanf("%s", str);
    
    printf("Entered String is = %s \n", str);
    
    free(str);

    return 0;
}
