
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX 256

struct str
{
    char cont[100];
};

int anagram(struct str s1, struct str s2)
{
    //Check if both have same length
    if(strlen(s1.cont) != strlen(s2.cont))
        return 0;


    int count[MAX];
    for(int i=0; i<256; i++)
        count[i]=0;


    for(int i=0; s1.cont[i] != '\0'; i++)
    {
        int ch1=s1.cont[i];
        int ch2=s2.cont[i];

        count[ch1] += 1;
        count[ch2] -= 1;
    }



    for(int i=0; i< MAX; i++)
    {
        if(count[i] != 0)
            return 0;
    }

    return 1;

}

int main()
{
    struct str str1, str2;

    printf("Enter first string\n");
    fgets(str1.cont, 100, stdin);

    printf("Enter second string\n");
    fgets(str2.cont, 100, stdin);

    int result = anagram(str1, str2);

    if(result == 0)
        printf("Not an Anagram\n");
    else
        printf("Two strings are Anagram\n");

    return 0;
}
