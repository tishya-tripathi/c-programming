/*************************
1. Write a program that declares and intializes a strucutre variable.
print the values of that structure variable
Consider :: the use case of a book stall and following details
book_id, book_title, author, price
************************/
#include <stdio.h>

struct bookstall
{
    int book_id;
    char book_title[100];
    char author[100];
    int price;
    
};

void accept(struct bookstall* b)
{
    printf("Enter book details : book_id, book_title, author, price\n");
    scanf("%d%s%s%d", &b->book_id, b->book_title, b->author, &b->price);
}

void display(struct bookstall b)
{
    printf("Displaying book details :\n");
    printf("book_id = %d\nbook_title = %s\nauthor = %s\nprice = %d\n", b.book_id, b.book_title, b.author, b.price);
}

int main()
{
    struct bookstall b;
    
    accept(&b);
    
    display(b);

    return 0;
}
