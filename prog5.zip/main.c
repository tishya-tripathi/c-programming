/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int n, factors;
    printf("Enter the value of n\n");
    scanf("%d", &n);
    
    printf("Displaying prime nos from 2 to %d :\n", n);
    
    for(int i=2; i<=n; i++)
    {
            factors=0;
            for(int j=1; j<=n; j++)
            {
                if(i%j == 0)
                    factors++;
                    
            }
            
            if(factors==2)
                printf("%d is Prime no\n", i);
    }

    return 0;
}
