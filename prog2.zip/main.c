/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    
    int i, n, a[100];
    i=0;
    printf("ENter an integer\n");
    scanf("%d", &n);

    while(n != 0)
    {
        a[i] = n%10;
        n /= 10;
        i++;
    }
    printf("Displaying digits in same order\n");
    for(int j= i-1; j>=0; j--)
        printf("%d", a[j]);
    
    
    return 0;
}
