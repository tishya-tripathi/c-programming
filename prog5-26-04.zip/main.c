/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int cmp(char* s1, char* s2)
{
    while(*s1 != '\0' && *s2 != '\0')
    {
        if(*s1 != *s2)
        {
            return 0;
        }
        s1++;
        s2++;
    }
    
    return 1;
    
}

int main()
{
    char s1[100], s2[100];
    printf("Enter string 1\n");
    scanf("%s", s1);
    printf("Enter string 2\n");
    scanf("%s", s2);
    
    int result = cmp(s1, s2);
    
    if(result == 0)
        printf("strings 1 and 2 are Not Equal\n");
    else
        printf("strings 1 and 2 are Equal\n");
        
    

    return 0;
}
