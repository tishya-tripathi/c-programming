/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int n, i, isPrime=1;
    printf("Enter a no\n");
    scanf("%d", &n);
    
    for(i=2; i<=n/2; i++)
    {
        if(n%i == 0)
        {
            isPrime=0;
            break;
        }
    }
    
    if(isPrime==1)
        printf("%d is Prime\n", n);
    else 
        printf("%d is not Prime\n", n);
    return 0;
}
