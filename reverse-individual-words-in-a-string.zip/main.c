/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//Reverse individual words in a string

void reverse(char s[])
{
    int stack[20];
    int top=-1;

    printf("Result = ");

    for(int i=0; s[i] != '\0'; i++)
    {
        if(s[i] == ' ')
        {
            //Empty stack
            while(top>=0)
            {
                printf("%c", stack[top--]);
            }

            printf(" ");
        }
        else
        {
            stack[++top]=s[i];
        }
    }
}

int main()
{
    char str[100];
    printf("Enter a string\n");
    fgets(str, 100, stdin);


    // Add ' ' at the end
    int len = strlen(str);
    str[len-1] = ' ';
    str[len] = '\0';



    reverse(str);

    return 0;
}