/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int n;
    printf("Enter a no\n");
    scanf("%d", &n);
    
    int l, m, i, a[100];
    l=0;
    m=n;
    i=0;
    
    
    while(m != 0)
    {
        a[i++]=m%10;
        l++;
        m /= 10;
    }
    
    int mid=l/2;
    
    // if l is Even
    if(l%2 == 0)
    {
        printf("%d%d\n", a[mid], a[mid-1]);
    }
    
    // if l is Odd
    else
    {
        printf("%d\n", a[mid]);
    }
    
    
    return 0;
}
