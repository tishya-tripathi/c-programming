/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

struct num 
{ 
    int usn; 
    char name[50];
    
};

// display, insert, ascending, descending, delete, search
void insert(struct num s[], int n)
{
    
    for(int i=0; i<n; i++)
    {
        printf("enter Student %d details: \n", i+1);
        scanf("%d%s", &s[i].usn, s[i].name);
    }
}

void sortAscending(struct num s[], int n)
{
    for(int i=0; i<n; i++)
    {
        for(int j=i+1; j<n; j++)
        {
            if(s[i].usn > s[j].usn)
            {
                
                struct num temp = s[i];
                s[i] = s[j];
                s[j] = temp;
            }
        }
    }
}

void delete(struct num s[], int n)
{
    
    int key;
    printf("enter student usn to be deleted\n");
    scanf("%d", &key);
    
    int pos=binSearch(s, n, key);
    
    if(pos==-1)
    {
        printf("Elem not present !\n");
        return;
    }
    
    for(int i=pos; i<n; i++)
        s[i]= s[i+1];
        
}

int binSearch(struct num s[], int n, int key)
{
    int low=0;
    int high=n-1;
    
    while(low<=high)
    {
        int mid = (low+high)/2;
        
        if(s[mid].usn == key)
            return mid;
        if(s[mid].usn < key)
            low = mid+1;
        else
            high = mid-1;
    }
    return -1;
}
void sortDescending(struct num s[], int n)
{
    for(int i=0; i<n; i++)
    {
        for(int j=i+1; j<n; j++)
        {
            if(s[i].usn > s[j].usn)
            {
                
                struct num temp = s[i];
                s[i] = s[j];
                s[j] = temp;
            }
        }
    }
}

void display(struct num s[], int n)
{
    printf("Printing Student details:\n");
    for(int i=0; i<n; i++)
    {
        printf("Student %d : \n", i+1);
        printf("USN = %d\t Name=%s\n", s[i].usn, s[i].name);
    }
}


int main()
{
    int n;
    printf("Enter no of students\n");
    scanf("%d", &n);
    
    struct num s[n];
    
    insert(s, n);
    sortAscending(s, n);
    
    display(s, n);
    
    

    return 0;
}
