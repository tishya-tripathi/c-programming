/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

void read_arr(int a[], int n)
{
    printf("enter array elements\n");
    for(int i=0; i<n; i++)
        scanf("%d", &a[i]);
}


void search(int a[], int n, int key)
{
    int first, last, flag;
    first=last=flag=-1;
    
    for(int i=0; i<n; i++)
    {
        if(key == a[i])
        {
            flag=1;
            if(first==-1)
                first=i+1;
            last=i+1;
        }
    }
    
    if(flag==-1)
        printf("Search Failure\n");
    else
    {
        printf("First occurence=%d\nLast occurence=%d\n", first, last);
    }
    
}

int main()
{
    int arr_size;
    printf("Enter the number of elements \n");
    scanf(   "%d", &arr_size  );
    
    int arr[arr_size];
    
    read_arr(arr, arr_size);
    
    int key;
    printf("Enter the key \n");
    scanf(   "%d", &key  );
    
    search(arr, arr_size, key);

    return 0;
}
