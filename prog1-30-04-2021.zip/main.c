/******************************************************************************
1. Write a  menu based program to implement a simple stack (static), 
 Implmenet functinos to add, delete and display the content of the stack 
 
*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>

#define MAX 20

void add(int s[], int* top, int ele)
{
    if(*top == MAX-1)
    {
        printf("Stack Overflow\n");
        return;
    }
    s[++(*top)] = ele;
}

void delete(int s[], int* top)
{
    if(*top == -1)
    {
        printf("Stack Underflow\n");
        return;
    }
    
    printf("Elem deleted= %d", s[(*top)--]);
}
void display(int s[], int top)
{
    if(top == -1)
    {
        printf("Stack Underflow\n");
        return;
    }
    printf("Displaying elem\n");
    for(int i=top; i>=0; i--)
        printf("%d\t", s[i]);
        
    printf("\n");
}

int main()
{
    int stack[MAX], top;
    top=-1;
    
    int ch;

    printf("\n\n\n\n~~~~~~Menu~~~~~~ : ");
    printf("\n=>1.Add an Element to Stack  ");
    printf("\n=>2.Delete an Element from Stack ");
    printf("\n=>3.Display ");
    printf("\n=>4.Exit");


    int ele;

    while(1)
    {
        printf("\nEnter your choice: ");
        scanf("%d", &ch);

        switch(ch)
        {
        case 1:
            printf("enter elem\n");
            scanf("%d", &ele);
            add(stack, &top, ele);
            break;

        case 2:
            delete(stack, &top);
            break;

        case 3:
            display(stack, top);
            break;

        case 4:
            exit(0);
            break;


        default: printf("Enter valid choice\n");
        }
    }


    return 0;
}
