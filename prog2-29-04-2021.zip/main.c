/******************************************************************************

2. Write a program to do the following (Use  array of structures)
    a. Create a book database (title, author, rice, no_pages)
    b. Update the book price based on the title.
    c. Display appropriate message if updation fails.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#define SIZE 10

struct book
{
    char title[100];
    char author[100];
    int price;
    int pg;
};

void create(struct book* b,int n)
{
    
    for(int i=0; i<n; i++)
    {
        printf("Enter details for book %d :\n", i+1);
        
        scanf("%s%s%d%d", b->title, b->author, &b->price, &b->pg);
        
        b++;
    }
}

void updatePrice(struct book* b,int n)
{
    char key[100];
    printf("Enter book title whose price is to be updated\n");
    scanf("%s", key);
    
    for(int i=0; i<n; i++)
    {
        if(strcmp(key, b->title) == 0)
        {
            int newPrice;
            printf("enter new price");
            scanf("%d", &newPrice);
            
            b->price = newPrice;
            return;
        }
        
        b++;
    }
    
    printf("Title not found\n");
}


int main()
{
    int n;
    printf("Enter no of books\n");
    scanf("%d", &n);
    
    struct book b[n];
    
    create(b, n);

    updatePrice(b, n);
        
    return 0;
}
