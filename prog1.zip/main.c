/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<stdlib.h>

int main()
{
    int n;
    printf("Enter a given integer\n");
    scanf("%d", &n);
    
    printf("Printing the digits\n");
    
    while(n != 0)
    {
        printf("%d", n%10);
        n /= 10;
        
    }
    
    return 0;
}
