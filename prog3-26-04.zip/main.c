/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    char str[100];
    printf("Enter a string\n");
    fgets(str, 100, stdin);
    
    char newString[10][10];     //Store a word in each row
    int i, j, k;
    
    j=0;
    k=0;
    
    int len = strlen(str);
    
    printf("Splitting the string into words :\n");
    
    for(i=0; i <= len; i++)
    {
        if(str[i] == '\0' || str[i] == ' ')
        {
            newString[k][j] = '\0';
            k++;                    
            j=0;
        }
        
        else
        {
            newString[k][j++] = str[i];
        }
    }
    
    for(i=0; i<k; i++)
    {
        printf("%s\n", newString[i]);
    }
    
    
    return 0;
}

























